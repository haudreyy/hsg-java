
/**
 * Write a description of class Oven here.
 *
 * @author Jonathan Gruss
 * @version 15.11.22
 */
public class Oven extends Producer {
    public Oven() {
        super();
    }

    @Override
    public String toString() {
        return "[Oven]";
    }
}
