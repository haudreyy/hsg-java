
/**
 * Write a description of class DoeMachine here.
 *
 * @author Jonathan Gruss
 * @version 15.11.22
 */
public class KneadingMachine extends Producer
{

    public KneadingMachine(){
        super();
    }

    @Override
    public String toString() {
        return "[KneadingMachine]";
    }
}
