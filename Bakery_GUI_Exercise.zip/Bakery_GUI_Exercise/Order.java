import java.util.ArrayList;

/**
 * This class contains the order information.
 *
 * @author (Yasmine Antille)
 * @version (1.0.0)
 */
public class Order
{
    private int orderNr; 
    private int amountOrderedBreads; 
    private String orderStatus; 
    private ArrayList <Produce> orderedProducts;

    /**
     * Constructor for objects of class Order
     */
    public Order(int OrderNr, int breads, String customerName)
    {
        this.orderedProducts = new ArrayList();
        this.orderNr = orderNr; 
        this.amountOrderedBreads = breads; 
        this.orderStatus = "Ordered"; 
        for (int i = 0; i<breads; i++) {
            Bread bread = new Bread(customerName); 
            orderedProducts.add(bread); 
        }
    }

    public int getOrderNr() {
        return orderNr; 
    }
    
    public int getAmountOrderedBreads() {
        return amountOrderedBreads; 
    }
    
    public void setOrderStatus(String status) {
        this.orderStatus = status; 
    }
    
    public String getOrderStatus() {
        return orderStatus; 
    }
}
