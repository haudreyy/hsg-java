import java.awt.*;

import javax.swing.*;

public class GuiSpringLayout {

    private final GUIController controller;

    public GuiSpringLayout(GUIController controller) {
        this.controller = controller;
        createWindow();
    }

    public static void main(String[] args) {
        Baker baker = new Baker();
        Bakery bakery = new Bakery(baker);

        GUIController controller = new GUIController(bakery);
        GuiSpringLayout gui = new GuiSpringLayout(controller);
    }

    private void createWindow() {
        JFrame frame = new JFrame("Bakery with SpringLayout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        createUI(frame);
        frame.setSize(560, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void createUI(final JFrame frame){
        JPanel panel = new JPanel();
        SpringLayout layout = new SpringLayout();

        panel.setLayout(layout);

        // Bread label and textfield
        JLabel labelBread = new JLabel("Number of breads");
        JTextField textfieldBread = new JTextField();
        panel.add(labelBread);
        panel.add(textfieldBread);

        // Customer name
        JLabel labelCustomerName = new JLabel("Customer Name");
        JTextField textfieldCustomerName = new JTextField();
        panel.add(labelCustomerName);
        panel.add(textfieldCustomerName);

        // button to send order
        JButton buttonSendOrder = new JButton("Send Order");
        panel.add(buttonSendOrder);

        buttonSendOrder.addActionListener(arg0 -> {
            int breads = Integer.parseInt(textfieldBread.getText());
            String name = textfieldCustomerName.getText();
            String status = controller.onOrder(breads, name);
            System.out.println(status);
        });


        layout.putConstraint(SpringLayout.WEST, labelBread, 10, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, labelBread, 25, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.NORTH, textfieldBread, 25, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, textfieldBread, 20, SpringLayout.EAST, labelBread);
        layout.putConstraint(SpringLayout.EAST, panel, 20, SpringLayout.EAST, textfieldBread);


        layout.putConstraint(SpringLayout.WEST, labelCustomerName, 10, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, labelCustomerName, 25, SpringLayout.NORTH, labelBread);
        layout.putConstraint(SpringLayout.EAST, labelCustomerName, 0, SpringLayout.EAST, labelBread);
        layout.putConstraint(SpringLayout.NORTH, textfieldCustomerName, 25, SpringLayout.NORTH, textfieldBread);
        layout.putConstraint(SpringLayout.WEST, textfieldCustomerName, 20, SpringLayout.EAST, labelCustomerName);
        layout.putConstraint(SpringLayout.EAST, textfieldBread, 0, SpringLayout.EAST, textfieldCustomerName);

        layout.putConstraint(SpringLayout.WEST, buttonSendOrder, 10, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, buttonSendOrder, 25, SpringLayout.NORTH, labelCustomerName);


        frame.getContentPane().add(panel, BorderLayout.CENTER);
    }
}
