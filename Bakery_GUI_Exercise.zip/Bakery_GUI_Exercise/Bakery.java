import java.util.HashMap;

/**
 * Write a description of class Bakery here.
 *
 * @author Jonathan Gruss
 * @version 15.11.22
 */
public class Bakery
{
    private Baker baker;
    private HashMap<Integer, Produce> produces;
    private static int produceId = 0;
    private int orderNr; 

    public Bakery(Baker baker)
    {
        produces = new HashMap<>();
        
        orderNr = 0; 
        
        this.baker = baker;
        baker.start();
    }

    public void addProduce(Produce produce) {
        this.produces.put(produceId++, produce);
        baker.addProduce(produce);
    }
    
    public Order giveUpOrder(int breads, String customerName) {
        orderNr += 1;
        // Since currently only breads, no need to further check produce
        Order order = new Order(orderNr, breads, customerName); 
        return order; 
    }
    
    public String getStatus() {
        return String.format("Current orders: %d", orderNr);
    }

    public static void main(String[] args) {
        Baker baker = new Baker();
        Bakery bakery = new Bakery(baker);
        
        GUIController controller = new GUIController(bakery); 
        GUI gui = new GUI(controller);

        // bakery.addProduce(new Bread("John"));
        // bakery.addProduce(new Bread("Jane"));

        // ThreadUtil.sleep(10_000);
        //System.exit(0);

    }
}
