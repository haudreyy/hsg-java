import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;  
import javax.swing.JLabel;  
import javax.swing.JTextField;

/**
 * Write a description of class GUI here.
 *
 * @author (Yasmine Antille)
 * @version (1.0.0)
 */
public class GUI extends JFrame
{ 
    private final GUIController controller;

    public GUI(GUIController controller){
        this.controller = controller;
        initWindow();
    }

    protected void initWindow() 
    {
        JLabel welcomeLabel = new JLabel("Welcome to the Happy Bakery!");
            
        JLabel label_bread             = new JLabel("Number of breads");
        JLabel label_customerName      = new JLabel("Customer Name"); 
        JLabel label_orderconfirmation = new JLabel("Order status will be updated here.");
        JLabel label_bakerystatus     = new JLabel("Bakery status:");
        
        JTextField textfield_bread         = new JTextField();
        JTextField textfield_customerName  = new JTextField(); 
        
        JButton button_sendorder        = new JButton("Send Order");
        JButton button_refreshstatus    = new JButton("Refresh Status");

        // action listener zu button hinzufügen, der dann auf Knopfdruck
        // eine Bestellung erstellt (controller.onOrder)
        // und das order confirmation label updated
        button_sendorder.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                int breads = Integer.parseInt(textfield_bread.getText());
                String name = textfield_customerName.getText();
                String status = controller.onOrder(breads, name);
                label_orderconfirmation.setText(status);
            }
        });

        // Action listener with lambda function () -> {}
        button_refreshstatus.addActionListener(arg0 -> {
            String status = controller.onStatus();
            label_bakerystatus.setText(status);
        });

        // Positionieren
        label_bread.setBounds(10, 50, 1000, 25); 
        textfield_bread.setBounds(180, 50, 100, 25);
        label_customerName.setBounds(10,80, 100, 25);
        textfield_customerName.setBounds(180,80,100,25);
        welcomeLabel.setBounds(10, 10, 1000, 25); 
        label_orderconfirmation.setBounds(10,110, 1000, 25);
        label_bakerystatus.setBounds(10,140, 400, 25);
        button_sendorder.setBounds(10,170,150,30);
        button_refreshstatus.setBounds(190,170,150,30);
    
        // Alle Elemente zum panel hinzufügen
        this.add(welcomeLabel); 
        this.add(label_bread);
        this.add(label_customerName); 
        this.add(label_orderconfirmation);
        this.add(label_bakerystatus);
        this.add(textfield_bread);
        this.add(textfield_customerName); 
        this.add(button_sendorder);
        this.add(button_refreshstatus);
        
        // GUI öffnen
        setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(370,250);
        this.setVisible(true);
    }
}