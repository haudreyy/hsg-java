import java.util.HashMap;
import java.util.LinkedList;

/**
 * Write a description of class Baker here.
 *
 * @author Jonathan Gruss
 * @version 15.11.22
 */
public class Baker extends Thread
{
    private LinkedList<Produce> produceToProcess;
    private LinkedList<Produce> produceInProcess;

    private KneadingMachine kneadingMachine;
    private Oven oven;

    public Baker()
    {
        produceToProcess = new LinkedList<>();
        produceInProcess = new LinkedList<>();

        kneadingMachine = new KneadingMachine();
        oven = new Oven();

        kneadingMachine.start();
        oven.start();
    }

    public void addProduce(Produce produce) {
        this.produceToProcess.add(produce);
    }

    public void run(){
        while(true){
            // TODO: Ex1.1 - If there is any produce to process
            // add to processing list, set sequence, and start processing
            // poll retrieves and removes head of linked list (1st element)
            Produce nextProduce = produceToProcess.poll();

            if (nextProduce != null) {
                ThreadUtil.syncedPrintln("[Baker] moved into production: " + nextProduce);
                produceInProcess.add(nextProduce);
                setProductionSequence(nextProduce);
                nextProduce.startNextProductionStep();
            }
            // 1) check if not null
            // 2) (optional) system print
            // 3) add to in production list
            // 4) set sequence
            // 5) start next produce

            // TODO: Ex1.3 Check all produce in process
            // If any is processed, remove it

            for(Produce produce: produceInProcess) {
                if(produce.isProcessed()) {
                    produceInProcess.remove(produce);
                    ThreadUtil.syncedPrintln("[Baker] finished producing: " + produce);
                }
            }

            // 1)check produce in process
            // 2)check if is processed
            // 3)remove produce
            // 4) (optional) print

            ThreadUtil.sleep(1000);
        }
    }

    private void setProductionSequence(Produce produce) {
        LinkedList<Producer> productionSequence = new LinkedList<>();
        HashMap<Producer, Integer> productionTimes = new HashMap<>();

        // TODO: Ex1.2 - Add production sequence and times for each produce type

        if(produce instanceof Bread) {
            productionSequence.add(kneadingMachine);
            productionSequence.add(oven);
            productionTimes.put(kneadingMachine, Bread.KNEADING_TIME);
            productionTimes.put(oven, Bread.BAKING_TIME);

            //productionTimes.put(kneadingMachine, produce.getProductionTime(kneadingMachine));
            //productionTimes.put(oven, produce.getProductionTime(oven));
        }
        // bread instance
        // 1) kneadingmachine
        // 2) prod time for kneading
        // 3) oven
        // 4) prod time for oven

        produce.setProductionSequence(productionSequence);
        produce.setProductionTimes(productionTimes);
        ThreadUtil.syncedPrintln("[Baker] Kneading machine has kneading time : " + produce.getProductionTime(kneadingMachine));
    }
}
