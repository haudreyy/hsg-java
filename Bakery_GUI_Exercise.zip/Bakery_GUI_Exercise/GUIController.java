
/**
 * Write a description of class GUIController here.
 *
 * @author (Yasmine Antille)
 * @version (1.0.0)
 */
public class GUIController
{
    private Bakery bakery;
    
    public GUIController(Bakery bakery){
        this.bakery = bakery;
    }
    
    public String onOrder(int breads, String customerName){
        Order order = bakery.giveUpOrder(breads, customerName);
        return order.getOrderStatus();
    }
    
    public String onStatus(){
        return bakery.getStatus();
    }
}
